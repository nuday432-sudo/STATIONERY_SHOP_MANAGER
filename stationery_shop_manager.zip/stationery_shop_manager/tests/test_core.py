import csv
import json
import os
import sys
import tempfile
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stationery.importer import import_csv
from stationery.inventory import Shop, ShopError
from stationery.models import Product
from stationery.reports import summarize, build_warnings, export_all
from stationery.seed import build_demo_shop
from stationery.storage import load_shop, save_shop
from stationery.validation import (validate_sku, validate_price, validate_qty,
                                   validate_category, validate_name, ask)


def mk():
    return Shop([Product("WRT-001", "Pen", "Writing", 10.0, 10, 5, 20)])


class ValidationTests(unittest.TestCase):
    def test_sku(self):
        self.assertEqual(validate_sku(" wrt-001 "), "WRT-001")
        for bad in ("", "WRT001", "W-1", "123-ABC"):
            with self.assertRaises(ValueError):
                validate_sku(bad)

    def test_price(self):
        self.assertEqual(validate_price("1,250.456"), 1250.46)
        for bad in ("0", "-1", "abc", "nan", "inf", "", "1e9"):
            with self.assertRaises(ValueError):
                validate_price(bad)

    def test_qty(self):
        self.assertEqual(validate_qty("5"), 5)
        for bad in ("2.5", "-1", "x", "", "999999999"):
            with self.assertRaises(ValueError):
                validate_qty(bad)
        with self.assertRaises(ValueError):
            validate_qty("0", min_value=1)

    def test_category_and_name(self):
        self.assertEqual(validate_category("art & craft"), "Art & Craft")
        with self.assertRaises(ValueError):
            validate_category("toys")
        with self.assertRaises(ValueError):
            validate_name("<script>")

    def test_ask_loops_until_valid(self):
        answers = iter(["abc", "-3", "7"])
        msgs = []
        self.assertEqual(ask("> ", validate_qty, input_fn=lambda _: next(answers), out=msgs.append), 7)
        self.assertEqual(len(msgs), 2)


class ShopTests(unittest.TestCase):
    def test_sell_reduces_stock_and_records(self):
        s = mk()
        sale = s.sell("wrt-001", 4)
        self.assertEqual(s.products["WRT-001"].stock, 6)
        self.assertEqual(sale.total, 40.0)

    def test_oversell_rejected(self):
        with self.assertRaises(ShopError):
            mk().sell("WRT-001", 11)

    def test_unknown_sku(self):
        with self.assertRaises(ShopError):
            mk().get("ZZZ-999")

    def test_restock_and_status(self):
        s = mk()
        p = s.products["WRT-001"]
        s.sell("WRT-001", 5)
        self.assertEqual(p.status, "LOW")  # boundary: stock == reorder level
        s.sell("WRT-001", 5)
        self.assertEqual(p.status, "OUT")
        s.restock("WRT-001", 20)
        self.assertEqual(p.status, "OK")

    def test_duplicate_add(self):
        with self.assertRaises(ShopError):
            mk().add_product(Product("WRT-001", "Dup", "Writing", 1.0, 1, 1))

    def test_search(self):
        s = build_demo_shop()
        self.assertTrue(all("pen" in p.name.lower() or "pen" in p.sku.lower() for p in s.search("pen")))
        self.assertTrue(all(p.category == "Geometry" for p in s.search("", "Geometry")))


class PersistenceTests(unittest.TestCase):
    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x.json")
            s = build_demo_shop()
            save_shop(s, path)
            s2, status = load_shop(path)
            self.assertEqual(status, "ok")
            self.assertEqual(s.to_dict(), s2.to_dict())

    def test_missing_and_corrupt(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x.json")
            self.assertEqual(load_shop(path)[1], "new")
            with open(path, "w") as fh:
                fh.write("{not json")
            shop, status = load_shop(path)
            self.assertEqual(status, "corrupt")
            self.assertEqual(len(shop.products), 0)
            self.assertTrue(any(".corrupt-" in f for f in os.listdir(d)))

    def test_invalid_values_treated_as_corrupt(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x.json")
            with open(path, "w") as fh:
                json.dump({"products": [{"sku": "bad", "name": "x"}]}, fh)
            self.assertEqual(load_shop(path)[1], "corrupt")


class ImportTests(unittest.TestCase):
    def test_import_with_errors(self):
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "in.csv")
            with open(src, "w", newline="") as fh:
                w = csv.writer(fh)
                w.writerow(["sku", "name", "category", "unit_price", "stock", "reorder_level"])
                w.writerow(["NEW-001", "Good Item", "Paper", "10", "5", "2"])
                w.writerow(["NEW-002", "Bad Price", "Paper", "-1", "5", "2"])
                w.writerow(["WRT-001", "Duplicate", "Writing", "10", "5", "2"])
            shop = mk()
            added, errors, log = import_csv(shop, src, d)
            self.assertEqual(added, 1)
            self.assertEqual(len(errors), 2)
            self.assertTrue(errors[0].startswith("Row 3"))
            self.assertTrue(os.path.exists(log))

    def test_missing_file_and_header(self):
        shop = Shop()
        self.assertEqual(import_csv(shop, "/nope.csv")[0], 0)
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "h.csv")
            with open(src, "w") as fh:
                fh.write("a,b\n1,2\n")
            self.assertIn("missing column", import_csv(shop, src, d)[1][0])


class ReportTests(unittest.TestCase):
    def test_summary_numbers(self):
        s = mk()
        s.sell("WRT-001", 2, when=date.today())
        r = summarize(s)
        self.assertEqual(r["products"], 1)
        self.assertEqual(r["units_in_stock"], 8)
        self.assertEqual(r["revenue"], 20.0)
        self.assertEqual(r["status"]["OK"], 1)

    def test_warnings_and_exports(self):
        shop = build_demo_shop()
        levels = {w[0] for w in build_warnings(shop)}
        self.assertTrue({"CRITICAL", "WARNING", "NOTICE"} <= levels)
        with tempfile.TemporaryDirectory() as d:
            paths = export_all(shop, d)
            self.assertEqual(sorted(os.path.splitext(p)[1] for p in paths), [".csv", ".md", ".txt"])

    def test_empty_shop_summary(self):
        r = summarize(Shop())
        self.assertEqual(r["avg_price"], 0.0)
        self.assertIsNone(r["trend_pct"])


if __name__ == "__main__":
    unittest.main()
