#!/usr/bin/env python3
"""Stationery Shop Manager - menu-driven terminal app."""
import os
import sys
from functools import partial

from stationery import ui
from stationery.inventory import ShopError
from stationery.models import Product
from stationery.importer import import_csv
from stationery.reports import summarize, build_warnings, render_text, export_all
from stationery.seed import build_demo_shop, write_sample_files
from stationery.storage import load_shop, save_shop, audit
from stationery.validation import (CATEGORIES, ask, confirm, validate_sku, validate_name,
                                   validate_category, validate_price, validate_qty)

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "data", "shop_data.json")
AUDIT_FILE = os.path.join(BASE, "data", "audit.log")
EXPORT_DIR = os.path.join(BASE, "exports")
DEFAULT_IMPORT = os.path.join(BASE, "data", "legacy_import_sample.csv")

HEAD = ["SKU", "Name", "Category", "Price", "Stock", "Reorder", "Status"]
WIDTH = [8, 26, 15, 10, 6, 7, 6]
ALIGN = ["l", "l", "l", "r", "r", "r", "l"]

MENU = """
 1) View all products        7) Summary dashboard
 2) Add product              8) Export reports (MD / TXT / CSV)
 3) Record a sale            9) Import products from CSV
 4) Restock                 10) Edit price / reorder level
 5) Search products         11) Delete product
 6) Low-stock alerts        12) Load demo dataset
 0) Exit"""


def rows_for(products):
    return [[p.sku, p.name, p.category, f"{p.unit_price:,.2f}", p.stock, p.reorder_level, p.status]
            for p in products]


def show(products):
    """Table with fixed-width columns; colour is applied after padding."""
    rows = rows_for(products)
    ui.paginate(HEAD, rows, WIDTH, ALIGN)


def pick_product(shop, prompt="SKU: "):
    while True:
        raw = input(prompt).strip()
        if raw.lower() in ("q", "cancel"):
            return None
        try:
            return shop.get(raw)
        except ShopError as exc:
            print(ui.c(f"  ! {exc} (type q to cancel)", "red"))


class App:
    def __init__(self):
        self.shop, status = load_shop(DATA_FILE)
        self.status = status

    def save(self, note):
        save_shop(self.shop, DATA_FILE)
        audit(AUDIT_FILE, note)

    # ---- actions --------------------------------------------------------
    def view_all(self):
        show(sorted(self.shop.products.values(), key=lambda p: p.sku))

    def add_product(self):
        print(ui.c("Add product (Ctrl+C to cancel)", "bold"))
        while True:
            sku = ask("  SKU (e.g. WRT-011): ", validate_sku)
            if sku in self.shop.products:
                print(ui.c(f"  ! {sku} already exists.", "red"))
                continue
            break
        name = ask("  Name: ", validate_name)
        print("  Categories: " + ", ".join(CATEGORIES))
        cat = ask("  Category: ", validate_category)
        price = ask("  Unit price: ", validate_price)
        stock = ask("  Opening stock: ", partial(validate_qty, field="Stock"))
        level = ask("  Reorder level: ", partial(validate_qty, field="Reorder level"))
        rq = ask("  Reorder quantity [20]: ", partial(validate_qty, min_value=1, field="Reorder qty"), default=20)
        p = self.shop.add_product(Product(sku, name, cat, price, stock, level, rq))
        self.save(f"ADD {p.sku} '{p.name}' stock={p.stock} price={p.unit_price}")
        print(ui.c(f"  Added {p.sku} - {p.name}.", "green"))

    def sell(self):
        p = pick_product(self.shop)
        if not p:
            return
        print(f"  {p.name}: {p.stock} in stock at {ui.money(p.unit_price)}")
        qty = ask("  Quantity sold: ", partial(validate_qty, min_value=1, field="Quantity"))
        try:
            sale = self.shop.sell(p.sku, qty)
        except ShopError as exc:
            print(ui.c(f"  ! {exc}", "red"))
            return
        self.save(f"SALE {p.sku} qty={qty} total={sale.total}")
        print(ui.c(f"  Sold {qty} x {p.name} = {ui.money(sale.total)}", "green"))
        if p.status != "OK":
            print(ui.c(f"  ! {p.name} is now {p.status} ({p.stock} left, reorder level {p.reorder_level}).", "yellow"))

    def restock(self):
        p = pick_product(self.shop)
        if not p:
            return
        qty = ask(f"  Units received [{p.reorder_qty}]: ",
                  partial(validate_qty, min_value=1, field="Quantity"), default=p.reorder_qty)
        self.shop.restock(p.sku, qty)
        self.save(f"RESTOCK {p.sku} +{qty} -> {p.stock}")
        print(ui.c(f"  {p.name} now has {p.stock} units.", "green"))

    def search(self):
        kw = input("  Keyword (blank = any): ").strip()
        print("  Categories: " + ", ".join(CATEGORIES))
        raw = input("  Category (blank = any): ").strip()
        cat = None
        if raw:
            try:
                cat = validate_category(raw)
            except ValueError as exc:
                print(ui.c(f"  ! {exc}", "red"))
                return
        show(self.shop.search(kw, cat))

    def low_stock(self):
        items = self.shop.low_stock()
        if not items:
            print(ui.c("  All products are above their reorder levels.", "green"))
            return
        print(ui.c(f"  {len(items)} product(s) need attention:", "yellow"))
        rows = [[p.sku, p.name, p.stock, p.reorder_level, p.reorder_qty, p.status] for p in items]
        ui.paginate(["SKU", "Name", "Stock", "Level", "Order", "Status"], rows,
                    [8, 26, 6, 6, 6, 6], ["l", "l", "r", "r", "r", "l"])

    def dashboard(self):
        warns = build_warnings(self.shop)
        print(render_text(summarize(self.shop), warns))

    def export(self):
        paths = export_all(self.shop, EXPORT_DIR, AUDIT_FILE)
        print(ui.c("  Reports written:", "green"))
        for p in paths:
            print("   - " + os.path.relpath(p, BASE))

    def import_products(self):
        path = input(f"  CSV path [{os.path.relpath(DEFAULT_IMPORT, BASE)}]: ").strip() or DEFAULT_IMPORT
        added, errors, log = import_csv(self.shop, path, EXPORT_DIR)
        if added:
            self.save(f"IMPORT {path}: {added} added, {len(errors)} rejected")
        print(ui.c(f"  Imported {added} product(s); {len(errors)} row(s) rejected.", "green" if not errors else "yellow"))
        for e in errors[:10]:
            print(ui.c("   - " + e, "red"))
        if len(errors) > 10:
            print(f"   ... and {len(errors) - 10} more")
        if log:
            print(f"  Full error log: {os.path.relpath(log, BASE)}")

    def edit(self):
        p = pick_product(self.shop)
        if not p:
            return
        print(f"  Current: price {p.unit_price:.2f}, reorder level {p.reorder_level}, reorder qty {p.reorder_qty} (Enter keeps current)")
        price = ask("  New price: ", validate_price, default=p.unit_price)
        level = ask("  New reorder level: ", partial(validate_qty, field="Reorder level"), default=p.reorder_level)
        self.shop.update(p.sku, price=price, reorder_level=level)
        self.save(f"EDIT {p.sku} price={price} reorder_level={level}")
        print(ui.c("  Updated.", "green"))

    def delete(self):
        p = pick_product(self.shop)
        if p and confirm(f"  Delete {p.sku} - {p.name}?"):
            self.shop.delete(p.sku)
            self.save(f"DELETE {p.sku}")
            print(ui.c("  Deleted.", "green"))

    def load_demo(self):
        if self.shop.products and not confirm("  This replaces current data with the demo dataset. Continue?"):
            return
        self.shop = build_demo_shop()
        write_sample_files(os.path.join(BASE, "data"))
        self.save("LOAD demo dataset")
        print(ui.c(f"  Loaded {len(self.shop.products)} products and {len(self.shop.sales)} sales.", "green"))

    # ---- main loop ------------------------------------------------------
    def run(self):
        ui.banner()
        if self.status == "corrupt":
            print(ui.c("  ! Data file was unreadable - backed up as *.corrupt-* and a fresh one started.", "yellow"))
        elif self.status == "new" or not self.shop.products:
            print("  No saved data yet.")
            if confirm("  Load the demo dataset (42 products, 2 weeks of sales)?"):
                self.load_demo()
        else:
            print(f"  Loaded {len(self.shop.products)} products, {len(self.shop.sales)} sales.")
        warns = build_warnings(self.shop)
        crit = sum(1 for w in warns if w[0] == "CRITICAL")
        low = sum(1 for w in warns if w[0] == "WARNING")
        if crit or low:
            print(ui.c(f"  ! Alerts: {crit} out of stock, {low} running low (option 6).", "yellow"))

        actions = {"1": self.view_all, "2": self.add_product, "3": self.sell, "4": self.restock,
                   "5": self.search, "6": self.low_stock, "7": self.dashboard, "8": self.export,
                   "9": self.import_products, "10": self.edit, "11": self.delete, "12": self.load_demo}
        while True:
            print(MENU)
            choice = input("\nChoose an option: ").strip()
            if choice == "0":
                print("Goodbye! Data is saved.")
                return
            action = actions.get(choice)
            if not action:
                print(ui.c("  ! Please enter a number from the menu.", "red"))
                continue
            try:
                action()
            except (KeyboardInterrupt, EOFError):
                print("\n  (cancelled)")
            except OSError as exc:
                print(ui.c(f"  ! File error: {exc}", "red"))


if __name__ == "__main__":
    try:
        App().run()
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye!")
        sys.exit(0)
