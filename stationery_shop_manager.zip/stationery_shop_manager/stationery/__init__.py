"""Stationery Shop Manager - stock, sales and reorder tracking."""
__version__ = "1.0.0"
