from dataclasses import dataclass, asdict


@dataclass
class Product:
    sku: str
    name: str
    category: str
    unit_price: float
    stock: int
    reorder_level: int
    reorder_qty: int = 20

    @property
    def status(self):
        if self.stock == 0:
            return "OUT"
        if self.stock <= self.reorder_level:
            return "LOW"
        return "OK"

    def to_dict(self):
        return asdict(self)


@dataclass
class Sale:
    date: str  # ISO date YYYY-MM-DD
    sku: str
    qty: int
    unit_price: float

    @property
    def total(self):
        return round(self.qty * self.unit_price, 2)

    def to_dict(self):
        return asdict(self)
