"""Terminal helpers: ANSI colours, banner, fixed-width tables, pagination."""
import os
import sys

if os.name == "nt":
    os.system("")  # enables ANSI escape codes on Windows 10+

USE_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
CODES = {"red": "31", "green": "32", "yellow": "33", "cyan": "36", "bold": "1", "dim": "2"}
CURRENCY = "Rs."


def c(text, style):
    if not USE_COLOR:
        return str(text)
    return f"\033[{CODES[style]}m{text}\033[0m"


def money(x):
    return f"{CURRENCY}{x:,.2f}"


def status_tag(status):
    return {"OK": c("OK", "green"), "LOW": c("LOW", "yellow"), "OUT": c("OUT", "red")}[status]


def banner():
    lines = ["=" * 56,
             "   STATIONERY SHOP MANAGER   |   Campus Catalyst #88",
             "   Stock  *  Sales  *  Reorder levels",
             "=" * 56]
    print("\n".join(c(line, "cyan") for line in lines))


def _cell(text, width, align):
    text = str(text)
    if len(text) > width:
        text = text[: width - 1] + "~"
    return text.rjust(width) if align == "r" else text.ljust(width)


def format_table(headers, rows, widths, aligns=None):
    aligns = aligns or ["l"] * len(headers)
    sep = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    head = "| " + " | ".join(_cell(h, w, "l") for h, w in zip(headers, widths)) + " |"
    body = ["| " + " | ".join(_cell(v, w, a) for v, w, a in zip(r, widths, aligns)) + " |"
            for r in rows]
    return "\n".join([sep, head, sep, *body, sep])


def paginate(headers, rows, widths, aligns=None, page_size=15, input_fn=input):
    """Print a table page by page (Enter = next page, q = stop)."""
    if not rows:
        print(c("  No records found.", "yellow"))
        return
    total = len(rows)
    for start in range(0, total, page_size):
        print(format_table(headers, rows[start:start + page_size], widths, aligns))
        shown = min(start + page_size, total)
        print(c(f"  Showing {shown} of {total}", "dim"))
        if shown < total and input_fn("  [Enter] next page, [q] stop: ").strip().lower() == "q":
            break
