"""Defensive validation: pure validators + loop-until-valid input wrappers."""
import math
import re

CATEGORIES = ["Writing", "Paper", "Files & Folders", "Art & Craft",
              "Office Supplies", "Geometry", "Other"]
SKU_RE = re.compile(r"^[A-Z]{2,4}-\d{3,4}$")
NAME_RE = re.compile(r"^[\w .,&()'/+\-]+$")
MAX_PRICE = 100_000.0
MAX_QTY = 100_000


def validate_sku(value):
    v = str(value).strip().upper()
    if not SKU_RE.match(v):
        raise ValueError("SKU must look like WRT-001 (2-4 letters, dash, 3-4 digits).")
    return v


def validate_name(value):
    v = " ".join(str(value).split())
    if not 2 <= len(v) <= 60:
        raise ValueError("Name must be 2-60 characters.")
    if not NAME_RE.match(v):
        raise ValueError("Name contains unsupported characters.")
    return v


def validate_category(value):
    v = str(value).strip().lower()
    for cat in CATEGORIES:
        if cat.lower() == v:
            return cat
    raise ValueError("Category must be one of: " + ", ".join(CATEGORIES))


def validate_price(value):
    try:
        p = float(str(value).replace(",", "").strip())
    except ValueError:
        raise ValueError("Price must be a number, e.g. 49.50.") from None
    if math.isnan(p) or math.isinf(p):
        raise ValueError("Price must be a real number.")
    if not 0 < p <= MAX_PRICE:
        raise ValueError(f"Price must be greater than 0 and at most {MAX_PRICE:,.0f}.")
    return round(p, 2)


def validate_qty(value, min_value=0, field="Quantity"):
    try:
        q = int(str(value).replace(",", "").strip())
    except ValueError:
        raise ValueError(f"{field} must be a whole number.") from None
    if not min_value <= q <= MAX_QTY:
        raise ValueError(f"{field} must be between {min_value} and {MAX_QTY:,}.")
    return q


def ask(prompt, validator, default=None, input_fn=input, out=print):
    """Keep prompting until `validator` accepts the input."""
    while True:
        raw = input_fn(prompt).strip()
        if raw == "" and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValueError as exc:
            out(f"  ! {exc}")


def confirm(prompt, input_fn=input):
    while True:
        a = input_fn(prompt + " [y/n]: ").strip().lower()
        if a in ("y", "yes"):
            return True
        if a in ("n", "no"):
            return False
        print("  ! Please answer y or n.")
