"""Core business logic: stock, sales and reorder levels."""
from datetime import date

from .models import Product, Sale
from .validation import (validate_sku, validate_name, validate_category,
                         validate_price, validate_qty)


class ShopError(Exception):
    """Raised for business-rule violations (unknown SKU, not enough stock...)."""


class Shop:
    def __init__(self, products=None, sales=None):
        self.products = {p.sku: p for p in (products or [])}
        self.sales = list(sales or [])

    # ---- products -------------------------------------------------------
    def get(self, sku):
        try:
            return self.products[validate_sku(sku)]
        except ValueError as exc:
            raise ShopError(str(exc)) from None
        except KeyError:
            raise ShopError(f"No product with SKU {sku.strip().upper()}.") from None

    def add_product(self, product):
        if product.sku in self.products:
            raise ShopError(f"SKU {product.sku} already exists.")
        self.products[product.sku] = product
        return product

    def update(self, sku, price=None, reorder_level=None, reorder_qty=None):
        p = self.get(sku)
        if price is not None:
            p.unit_price = price
        if reorder_level is not None:
            p.reorder_level = reorder_level
        if reorder_qty is not None:
            p.reorder_qty = reorder_qty
        return p

    def delete(self, sku):
        p = self.get(sku)
        del self.products[p.sku]
        return p

    # ---- stock & sales --------------------------------------------------
    def restock(self, sku, qty):
        if qty < 1:
            raise ShopError("Restock quantity must be at least 1.")
        p = self.get(sku)
        p.stock += qty
        return p

    def sell(self, sku, qty, when=None):
        if qty < 1:
            raise ShopError("Sale quantity must be at least 1.")
        p = self.get(sku)
        if qty > p.stock:
            raise ShopError(f"Only {p.stock} x {p.name} in stock; cannot sell {qty}.")
        p.stock -= qty
        sale = Sale((when or date.today()).isoformat(), p.sku, qty, p.unit_price)
        self.sales.append(sale)
        return sale

    # ---- queries --------------------------------------------------------
    def search(self, keyword="", category=None):
        kw = keyword.strip().lower()
        out = []
        for p in self.products.values():
            if category and p.category != category:
                continue
            if kw and kw not in p.name.lower() and kw not in p.sku.lower():
                continue
            out.append(p)
        return sorted(out, key=lambda p: p.sku)

    def low_stock(self):
        """Products at or below reorder level: out-of-stock first, then biggest shortfall."""
        items = [p for p in self.products.values() if p.status in ("OUT", "LOW")]
        return sorted(items, key=lambda p: (p.status != "OUT", p.stock - p.reorder_level, p.sku))

    # ---- persistence helpers -------------------------------------------
    def to_dict(self):
        return {"products": [p.to_dict() for p in self.products.values()],
                "sales": [s.to_dict() for s in self.sales]}

    @classmethod
    def from_dict(cls, data):
        """Rebuild a Shop, re-validating everything. Raises ValueError if bad."""
        if not isinstance(data, dict):
            raise ValueError("Top-level JSON must be an object.")
        shop = cls()
        for raw in data.get("products", []):
            p = Product(
                sku=validate_sku(raw["sku"]),
                name=validate_name(raw["name"]),
                category=validate_category(raw["category"]),
                unit_price=validate_price(raw["unit_price"]),
                stock=validate_qty(raw["stock"]),
                reorder_level=validate_qty(raw["reorder_level"]),
                reorder_qty=validate_qty(raw.get("reorder_qty", 20), 1),
            )
            if p.sku in shop.products:
                raise ValueError(f"Duplicate SKU {p.sku}.")
            shop.products[p.sku] = p
        for raw in data.get("sales", []):
            date.fromisoformat(raw["date"])
            shop.sales.append(Sale(raw["date"], validate_sku(raw["sku"]),
                                   validate_qty(raw["qty"], 1),
                                   validate_price(raw["unit_price"])))
        return shop
