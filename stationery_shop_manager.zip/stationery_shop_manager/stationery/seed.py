"""Realistic demo dataset (42 products + 14 days of sales), incl. edge cases."""
import csv
import json
import os
import random
from datetime import date, timedelta

from .inventory import Shop
from .models import Product

# sku, name, category, price, stock, reorder_level, reorder_qty
PRODUCTS = [
    ("WRT-001", "Blue Ball Pen (10 pack)", "Writing", 50, 120, 30, 60),
    ("WRT-002", "Black Gel Pen", "Writing", 20, 85, 25, 50),
    ("WRT-003", "HB Pencil (12 pack)", "Writing", 60, 6, 20, 40),          # low
    ("WRT-004", "Mechanical Pencil 0.5mm", "Writing", 45, 40, 15, 30),
    ("WRT-005", "Permanent Marker", "Writing", 35, 0, 10, 30),             # out
    ("WRT-006", "Whiteboard Marker", "Writing", 30, 22, 10, 25),
    ("WRT-007", "Highlighter Set (4)", "Writing", 120, 18, 8, 20),
    ("WRT-008", "Fountain Pen", "Writing", 250, 12, 5, 10),
    ("WRT-009", "Ink Bottle Blue", "Writing", 70, 15, 10, 20),
    ("WRT-010", "Gel Refill Pack", "Writing", 40, 200, 20, 40),            # overstock
    ("PAP-001", "A4 Notebook 200 pages", "Paper", 90, 70, 25, 50),
    ("PAP-002", "A5 Ruled Notebook", "Paper", 55, 90, 30, 60),
    ("PAP-003", "Spiral Notebook", "Paper", 110, 10, 15, 30),              # low
    ("PAP-004", "A4 Paper Ream 500", "Paper", 380, 25, 10, 20),
    ("PAP-005", "Sticky Notes 3x3", "Paper", 45, 60, 20, 40),
    ("PAP-006", "Graph Book", "Paper", 65, 35, 15, 30),
    ("PAP-007", "Chart Paper Sheet", "Paper", 10, 300, 100, 200),
    ("PAP-008", "Drawing Book", "Paper", 80, 28, 12, 25),
    ("PAP-009", "Index Cards (100)", "Paper", 40, 14, 10, 20),
    ("FIL-001", "Plastic Folder", "Files & Folders", 25, 120, 40, 80),
    ("FIL-002", "Box File", "Files & Folders", 150, 15, 6, 12),
    ("FIL-003", "Ring Binder", "Files & Folders", 180, 9, 8, 15),
    ("FIL-004", "Document Wallet", "Files & Folders", 30, 55, 20, 40),
    ("FIL-005", "Clip Board", "Files & Folders", 95, 8, 8, 15),            # boundary
    ("ART-001", "Water Colour Set 12", "Art & Craft", 160, 20, 8, 15),
    ("ART-002", "Crayons 24 shades", "Art & Craft", 90, 35, 12, 25),
    ("ART-003", "Sketch Pens 24", "Art & Craft", 130, 0, 10, 20),          # out
    ("ART-004", "Poster Colour Box", "Art & Craft", 140, 16, 6, 12),
    ("ART-005", "Paint Brush Set", "Art & Craft", 110, 25, 10, 20),
    ("ART-006", "Glitter Glue", "Art & Craft", 60, 18, 8, 15),
    ("ART-007", "Colour Pencils 36", "Art & Craft", 210, 11, 10, 20),
    ("OFF-001", "Stapler", "Office Supplies", 85, 30, 10, 20),
    ("OFF-002", "Staple Pins Box", "Office Supplies", 20, 500, 100, 200),
    ("OFF-003", "Paper Clips Box", "Office Supplies", 25, 140, 40, 80),
    ("OFF-004", "Scissors", "Office Supplies", 65, 24, 10, 20),
    ("OFF-005", "Glue Stick", "Office Supplies", 30, 75, 25, 50),
    ("OFF-006", "Transparent Tape", "Office Supplies", 25, 5, 20, 40),     # low
    ("OFF-007", "Scientific Calculator", "Office Supplies", 450, 10, 4, 8),
    ("GEO-001", "Geometry Box", "Geometry", 150, 40, 15, 30),
    ("GEO-002", "Scale 30cm", "Geometry", 20, 90, 30, 60),
    ("GEO-003", "Eraser (5 pack)", "Geometry", 25, 8, 30, 60),             # low
    ("GEO-004", "Sharpener", "Geometry", 10, 900, 60, 120),                # overstock
]


def build_demo_shop(today=None, seed=88):
    today = today or date.today()
    rng = random.Random(seed)
    shop = Shop([Product(sku, n, cat, float(pr), st, lv, rq)
                 for sku, n, cat, pr, st, lv, rq in PRODUCTS])
    # Popular items sell more; the last 7 days are slightly busier than the 7 before.
    for back in range(13, -1, -1):
        day = today - timedelta(days=back)
        for _ in range(rng.randint(6, 12) + (3 if back < 7 else 0)):
            p = rng.choice(list(shop.products.values()))
            if p.stock == 0:
                continue
            qty = min(p.stock, rng.randint(1, 5 if p.unit_price < 100 else 2))
            shop.sell(p.sku, qty, when=day)
    return shop


def write_sample_files(data_dir="data"):
    """Write data/sample_products.csv and data/sample_products.json."""
    os.makedirs(data_dir, exist_ok=True)
    shop = build_demo_shop()
    with open(os.path.join(data_dir, "sample_products.json"), "w", encoding="utf-8") as fh:
        json.dump(shop.to_dict(), fh, indent=2)
    with open(os.path.join(data_dir, "sample_products.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["sku", "name", "category", "unit_price", "stock", "reorder_level", "reorder_qty"])
        for sku, n, cat, pr, st, lv, rq in PRODUCTS:
            w.writerow([sku, n, cat, pr, st, lv, rq])
    # A deliberately messy legacy file for demoing the import error log.
    with open(os.path.join(data_dir, "legacy_import_sample.csv"), "w", newline="", encoding="utf-8") as fh:
        fh.write("sku,name,category,unit_price,stock,reorder_level,reorder_qty\n"
                 "NEW-001,Correction Tape,Office Supplies,35,40,10,20\n"
                 "NEW-002,Washi Tape Roll,Art & Craft,45,25,8,15\n"
                 "bad sku,Broken Row,Writing,10,5,2,10\n"
                 "NEW-003,Negative Price Pen,Writing,-5,10,2,10\n"
                 "NEW-004,Letter Stock,Writing,abc,10,2,10\n"
                 "NEW-005,Unknown Category,Gadgets,20,10,2,10\n"
                 "NEW-006,Fractional Stock,Paper,20,2.5,2,10\n"
                 "WRT-001,Duplicate Of Existing,Writing,50,10,2,10\n"
                 ",Blank SKU,Paper,10,10,2,10\n"
                 "NEW-007,Stick-On Flags,Paper,30,60,15,30\n")
