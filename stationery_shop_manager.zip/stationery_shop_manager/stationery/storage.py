"""JSON persistence with corruption handling + plain-text audit log."""
import json
import os
from datetime import datetime

from .inventory import Shop


def load_shop(path):
    """Return (shop, status) where status is 'ok', 'new' or 'corrupt'."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return Shop.from_dict(json.load(fh)), "ok"
    except FileNotFoundError:
        return Shop(), "new"
    except (json.JSONDecodeError, KeyError, TypeError, ValueError, OSError):
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        try:
            os.replace(path, f"{path}.corrupt-{stamp}")
        except OSError:
            pass
        return Shop(), "corrupt"


def save_shop(shop, path):
    """Atomic save: write temp file, then replace."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(shop.to_dict(), fh, indent=2)
    os.replace(tmp, path)


def audit(path, message):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} | {message}\n")
