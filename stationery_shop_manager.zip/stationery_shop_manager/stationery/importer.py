"""Bulk CSV import with row-by-row validation and an error log."""
import csv
import os
from datetime import datetime

from .models import Product
from .validation import (validate_sku, validate_name, validate_category,
                         validate_price, validate_qty)

REQUIRED = ["sku", "name", "category", "unit_price", "stock", "reorder_level"]


def import_csv(shop, path, log_dir="exports"):
    """Import products. Returns (added, errors, log_path_or_None)."""
    added, errors = 0, []
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            headers = [h.strip().lower() for h in (reader.fieldnames or [])]
            missing = [c for c in REQUIRED if c not in headers]
            if missing:
                return 0, [f"Header: missing column(s): {', '.join(missing)}"], None
            for line_no, raw in enumerate(reader, start=2):
                row = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
                try:
                    p = Product(
                        sku=validate_sku(row["sku"]),
                        name=validate_name(row["name"]),
                        category=validate_category(row["category"]),
                        unit_price=validate_price(row["unit_price"]),
                        stock=validate_qty(row["stock"], field="Stock"),
                        reorder_level=validate_qty(row["reorder_level"], field="Reorder level"),
                        reorder_qty=validate_qty(row.get("reorder_qty") or 20, 1, "Reorder qty"),
                    )
                    if p.sku in shop.products:
                        raise ValueError(f"duplicate SKU {p.sku} (already in shop)")
                    shop.products[p.sku] = p
                    added += 1
                except ValueError as exc:
                    errors.append(f"Row {line_no}: {exc}")
    except FileNotFoundError:
        return 0, [f"File not found: {path}"], None
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        return 0, [f"Could not read file: {exc}"], None

    log_path = None
    if errors:
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log")
        with open(log_path, "w", encoding="utf-8") as fh:
            fh.write(f"Import of {path}: {added} added, {len(errors)} rejected\n")
            fh.write("\n".join(errors) + "\n")
    return added, errors, log_path
