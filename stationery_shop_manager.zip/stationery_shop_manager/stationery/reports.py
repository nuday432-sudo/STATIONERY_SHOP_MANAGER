"""Summary metrics, warning flags and multi-format export."""
import csv
import os
from collections import defaultdict
from datetime import date, datetime, timedelta

OVERSTOCK_FACTOR = 10


def summarize(shop, today=None):
    today = today or date.today()
    products = list(shop.products.values())
    n = len(products)
    revenue = sum(s.total for s in shop.sales)
    units_sold = sum(s.qty for s in shop.sales)

    by_cat = defaultdict(lambda: {"products": 0, "units": 0, "value": 0.0, "revenue": 0.0})
    for p in products:
        row = by_cat[p.category]
        row["products"] += 1
        row["units"] += p.stock
        row["value"] += p.stock * p.unit_price
    cat_of = {p.sku: p.category for p in products}
    sold = defaultdict(lambda: [0, 0.0])
    for s in shop.sales:
        sold[s.sku][0] += s.qty
        sold[s.sku][1] += s.total
        if s.sku in cat_of:
            by_cat[cat_of[s.sku]]["revenue"] += s.total

    top = sorted(sold.items(), key=lambda kv: (-kv[1][0], kv[0]))[:5]
    top = [(sku, shop.products[sku].name if sku in shop.products else "(deleted)", q, r)
           for sku, (q, r) in top]

    daily = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        daily.append((d.isoformat(), sum(s.total for s in shop.sales if s.date == d.isoformat())))
    last7 = sum(v for _, v in daily)
    prev7 = sum(s.total for s in shop.sales
                if (today - timedelta(days=13)).isoformat() <= s.date
                <= (today - timedelta(days=7)).isoformat())
    change = None if prev7 == 0 else (last7 - prev7) / prev7 * 100

    return {
        "generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "products": n,
        "units_in_stock": sum(p.stock for p in products),
        "inventory_value": sum(p.stock * p.unit_price for p in products),
        "avg_price": (sum(p.unit_price for p in products) / n) if n else 0.0,
        "avg_stock": (sum(p.stock for p in products) / n) if n else 0.0,
        "status": {k: sum(1 for p in products if p.status == k) for k in ("OK", "LOW", "OUT")},
        "revenue": revenue, "units_sold": units_sold, "transactions": len(shop.sales),
        "avg_sale": (revenue / len(shop.sales)) if shop.sales else 0.0,
        "by_category": dict(sorted(by_cat.items())),
        "top_sellers": top, "daily": daily, "last7": last7, "prev7": prev7,
        "trend_pct": change,
    }


def build_warnings(shop):
    """Threshold warning flags: (level, message) tuples, most severe first."""
    out = []
    for p in shop.products.values():
        if p.status == "OUT":
            out.append(("CRITICAL", f"{p.sku} {p.name}: OUT OF STOCK - reorder {p.reorder_qty}"))
        elif p.status == "LOW":
            out.append(("WARNING", f"{p.sku} {p.name}: low ({p.stock} <= level {p.reorder_level})"))
        elif p.reorder_level > 0 and p.stock > OVERSTOCK_FACTOR * p.reorder_level:
            out.append(("NOTICE", f"{p.sku} {p.name}: possible overstock ({p.stock} units)"))
    order = {"CRITICAL": 0, "WARNING": 1, "NOTICE": 2}
    return sorted(out, key=lambda w: (order[w[0]], w[1]))


def _fmt(x):
    return f"Rs.{x:,.2f}"


def render_text(s, warnings):
    L = ["STATIONERY SHOP MANAGER - EXECUTIVE SUMMARY", f"Generated: {s['generated']}", "",
         "INVENTORY",
         f"  Products tracked : {s['products']}",
         f"  Units in stock   : {s['units_in_stock']:,}",
         f"  Inventory value  : {_fmt(s['inventory_value'])}",
         f"  Average price    : {_fmt(s['avg_price'])}",
         f"  Average stock    : {s['avg_stock']:.1f} units/product",
         f"  Status           : OK {s['status']['OK']} | LOW {s['status']['LOW']} | OUT {s['status']['OUT']}",
         "", "SALES",
         f"  Transactions     : {s['transactions']}",
         f"  Units sold       : {s['units_sold']:,}",
         f"  Revenue          : {_fmt(s['revenue'])}",
         f"  Average sale     : {_fmt(s['avg_sale'])}",
         "", "BY CATEGORY (products / units / stock value / revenue)"]
    for cat, r in s["by_category"].items():
        L.append(f"  {cat:<16} {r['products']:>3} {r['units']:>7,} {_fmt(r['value']):>14} {_fmt(r['revenue']):>14}")
    L += ["", "TOP SELLERS"]
    L += [f"  {i}. {sku} {name} - {q} units ({_fmt(rev)})"
          for i, (sku, name, q, rev) in enumerate(s["top_sellers"], 1)] or ["  (no sales yet)"]
    L += ["", "REVENUE - LAST 7 DAYS"]
    peak = max((v for _, v in s["daily"]), default=0) or 1
    L += [f"  {d}  {'#' * int(v / peak * 30):<30} {_fmt(v)}" for d, v in s["daily"]]
    if s["trend_pct"] is None:
        L.append("  Trend: not enough history to compare with the previous 7 days.")
    else:
        word = "up" if s["trend_pct"] >= 0 else "down"
        L.append(f"  Trend: {word} {abs(s['trend_pct']):.1f}% vs previous 7 days.")
    L += ["", f"ALERTS ({len(warnings)})"]
    L += [f"  [{lvl}] {msg}" for lvl, msg in warnings] or ["  None - all stock levels healthy."]
    return "\n".join(L) + "\n"


def render_markdown(s, warnings):
    L = ["# Stationery Shop Manager - Executive Summary", f"_Generated: {s['generated']}_", "",
         "## Key metrics", "| Metric | Value |", "|---|---|",
         f"| Products | {s['products']} |", f"| Units in stock | {s['units_in_stock']:,} |",
         f"| Inventory value | {_fmt(s['inventory_value'])} |",
         f"| Revenue | {_fmt(s['revenue'])} |", f"| Units sold | {s['units_sold']:,} |",
         f"| Stock status | OK {s['status']['OK']} / LOW {s['status']['LOW']} / OUT {s['status']['OUT']} |",
         "", "## By category", "| Category | Products | Units | Stock value | Revenue |", "|---|--:|--:|--:|--:|"]
    L += [f"| {k} | {r['products']} | {r['units']:,} | {_fmt(r['value'])} | {_fmt(r['revenue'])} |"
          for k, r in s["by_category"].items()]
    L += ["", "## Top sellers"]
    L += [f"{i}. **{name}** ({sku}) - {q} units, {_fmt(rev)}"
          for i, (sku, name, q, rev) in enumerate(s["top_sellers"], 1)] or ["_No sales yet._"]
    L += ["", "## Revenue, last 7 days", "| Date | Revenue |", "|---|--:|"]
    L += [f"| {d} | {_fmt(v)} |" for d, v in s["daily"]]
    if s["trend_pct"] is not None:
        L.append(f"\nTrend: **{s['trend_pct']:+.1f}%** vs previous 7 days.")
    L += ["", f"## Alerts ({len(warnings)})"]
    L += [f"- **{lvl}** - {msg}" for lvl, msg in warnings] or ["- None"]
    return "\n".join(L) + "\n"


def export_inventory_csv(shop, path):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["sku", "name", "category", "unit_price", "stock", "reorder_level",
                    "reorder_qty", "status", "stock_value"])
        for p in sorted(shop.products.values(), key=lambda p: p.sku):
            w.writerow([p.sku, p.name, p.category, p.unit_price, p.stock, p.reorder_level,
                        p.reorder_qty, p.status, round(p.stock * p.unit_price, 2)])


def export_all(shop, out_dir="exports", audit_path=None):
    """Write Markdown, plain-text and CSV reports. Returns list of paths."""
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    s, warns = summarize(shop), build_warnings(shop)
    paths = []
    for ext, text in (("md", render_markdown(s, warns)), ("txt", render_text(s, warns))):
        p = os.path.join(out_dir, f"summary_{stamp}.{ext}")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(text)
        paths.append(p)
    p = os.path.join(out_dir, f"inventory_{stamp}.csv")
    export_inventory_csv(shop, p)
    paths.append(p)
    if audit_path and os.path.exists(audit_path):
        p = os.path.join(out_dir, f"audit_{stamp}.txt")
        with open(audit_path, encoding="utf-8") as src, open(p, "w", encoding="utf-8") as dst:
            dst.write(src.read())
        paths.append(p)
    return paths
